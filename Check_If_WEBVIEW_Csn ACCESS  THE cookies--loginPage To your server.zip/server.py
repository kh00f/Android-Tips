from http.server import BaseHTTPRequestHandler, HTTPServer
import json

class Handler(BaseHTTPRequestHandler):

    def do_GET(self):
        if self.path == "/":
            self.send_response(200)
            self.send_header("Content-Type", "text/html")
            self.end_headers()

            with open("coockie.html", "rb") as f:
                self.wfile.write(f.read())

    def do_POST(self):
        if self.path == "/report":
            length = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(length)

            print("\n[+] Cookie test result:")
            print(body.decode())

            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(b'{"status":"received"}')

    def log_message(self, format, *args):
        pass


server = HTTPServer(("0.0.0.0", 8000), Handler)

print("Server running on http://0.0.0.0:8000")
server.serve_forever()
